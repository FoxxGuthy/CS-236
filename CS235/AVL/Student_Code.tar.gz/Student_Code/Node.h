#pragma once
#include "NodeInterface.h"

int const EMPTY = 0;

class Node :
	public NodeInterface
{
public:
	Node(int newData);
~Node();

int getData() { return data;}
NodeInterface* getLeftChild() { return leftChild; }
NodeInterface* getRightChild() { return rightChild; }
int getHeight();

//Extra Functions for implementation
int getBalance() { return balance; }


//Data Members
int data;
int balance;
int leftHeight;
int rightHeight;
Node* leftChild;
Node* rightChild;

};

