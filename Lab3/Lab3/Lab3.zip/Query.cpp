

#include "Query.h"

using namespace std;


Query::Query(Predicate p)
{
	myPred = p;
}

Query::~Query() {
	// TODO Auto-generated destructor stub
}


