
#include "Fact.h"

using namespace std;

Fact::Fact(Predicate p)
{
	myPred = p;
}

Fact::~Fact() {
	// TODO Auto-generated destructor stub
}


