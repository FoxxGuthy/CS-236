#pragma once

#include "Node.h"
class BST
{
public:
	BST();
	~BST();

	//required functions
	NodeInterface* getRootNode() { return root; }

	//these two are for calling within AVL, b/c we can't use root to call outside of BST
	//OVERLOAD THOSE SUCKERS
	bool insert(int data) { return insert(data, root, true); }
	bool erase(int data) { return erase(data, root, true); }

	//ACTUAL INSERT AND ERASE
	bool insert(int data, Node* &currentNode, bool begin);
	bool erase(int data, Node* &currentNode, bool begin);



	void clear();


private:
	Node* root;

	bool increase;
	bool decrease;

	enum balance_type { LEFT_HEAVY = -1, BALANCED = 0, RIGHT_HEAVY = +1 };

	Node* rotateRight(Node* &currentNode);
	Node* rotateLeft(Node* &currentNode);

	void rebalanceLeft(Node* &current, bool removal);
	void rebalanceRight(Node* &current, bool removal);

	void replaceParent(Node* &old_root, Node* &local_root);

	//bool begin;
};

