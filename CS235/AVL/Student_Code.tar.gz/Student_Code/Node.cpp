#include "Node.h"


Node::Node(int newData)
{
	data = newData;
	leftHeight = EMPTY;
	rightHeight = EMPTY;
	balance = EMPTY;
	leftChild = NULL;
	rightChild = NULL;
}


Node::~Node()
{
}

// will return the max height as well update. could write seperate set func, but who cares?
//ALSO: WILL NEVER CALL THIS. WE'RE GONNA USE BALANCE WITCHES
int Node::getHeight()
{
	if (this->leftChild == NULL) // no left child, so no left height
		this->leftHeight = EMPTY;

	else // its got a kid, get its height
		this->leftHeight = this->leftChild->getHeight();


	if (this->rightChild == NULL) // similar
		this->rightHeight = EMPTY;

	else 
		this->rightHeight = this->rightChild->getHeight();

	this->balance = rightHeight - leftHeight; // this will override all the heights in the tree. hypothetically

	//return statements
	if (leftHeight > rightHeight)
		return leftHeight + 1;

	else
		return rightHeight + 1;
}

