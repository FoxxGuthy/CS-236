#include "AVL.h"



AVL::AVL()
{
}


AVL::~AVL()
{
}

NodeInterface * AVL::getRootNode()
{
	return groot.getRootNode();
}

bool AVL::add(int data)
{
	return groot.insert(data);
}

bool AVL::remove(int data)
{
	return groot.erase(data);
}
