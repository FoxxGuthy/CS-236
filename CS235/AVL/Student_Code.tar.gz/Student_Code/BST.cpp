#include "BST.h"
//#include <iostream>



BST::BST()
{
	root = NULL;
}


BST::~BST()
{
	clear();
}

//from textbook
bool BST::insert(int data, Node* &currentNode, bool begin)
{
	// someimtes root is lost for no reason, this will reassign it the first time function is called
	if (begin)
		root = currentNode;
	begin = false;

	if (root == NULL)
	{
		root = new Node(data);
		increase = true;
		return true;
	}

	if (currentNode == NULL)
	{
		currentNode = new Node(data);
		increase = true;
		return true;
	}

	if (data < currentNode->getData()) // less than where we're looking, go left
	{
		bool returnValue = insert(data, currentNode->leftChild, begin);
		if (increase)
		{
			switch (currentNode->balance)
			{
			case BALANCED: //started as balance, by adding to left, now balance is -1
				currentNode->balance = LEFT_HEAVY;
				break;
			case RIGHT_HEAVY: // start at +1 balance, is now balance: 0
				currentNode->balance = BALANCED;
				//overall height unchanged
				increase = false;
				break;
			case LEFT_HEAVY: // started at -1, is now -2, critically unbalance, will need to rebalance(rotate)
				rebalanceLeft(currentNode, false); // rebalnce will act differently we replacing after removals
				increase = false;
				break;
			}
		}
		return returnValue;
	}

	else if (data > currentNode->getData()) // greater than current node, go right
	{
		bool returnValue = insert(data, currentNode->rightChild, begin);
		if (increase)
		{
			switch (currentNode->balance)
			{
			case BALANCED: // balance start at zero, now +1
				currentNode->balance = RIGHT_HEAVY;
				break;
			case LEFT_HEAVY: // start at -1, now 0
				currentNode->balance = BALANCED;
				increase = false;
				break;
			case RIGHT_HEAVY: //balance is now +2, rebalance
				rebalanceRight(currentNode, false);
				increase = false;
				break;
			}
		}
		return returnValue;
	}

	else // its not less than, or greater than, so it must be equal. already in tree. return false;
	{
		increase = false;
		return false;
	}
}

//right now simply removes, no balancing. From text book. 
bool BST::erase(int data, Node* &currentNode, bool begin)
{
   // cout << data << endl;
	 // an attempt to save the root from destruction 
	if (begin)
		root = currentNode;
	begin = false;


	//root->getHeight();

	if (currentNode == NULL) // not found
	{
		decrease = false;
		return false;
	}



	else
	{
		if (data < currentNode->data) // less than current
		{
			bool returnValue = erase(data, currentNode->leftChild, begin);
			if (decrease)
			{
				switch (currentNode->balance)
				{
				case BALANCED: // balance from 0 to +1
					currentNode->balance = RIGHT_HEAVY;
					decrease = false;
					break;
				case RIGHT_HEAVY: // balance was at +1, now is +2. critcal, must rebalance
					rebalanceLeft(currentNode, true);
					decrease = false;
					break;
				case LEFT_HEAVY: // balance from -1 to 0;
					currentNode->balance = BALANCED;
					//decrease still true
					break;
				}
			}
			return returnValue;
		}


		else if (data > currentNode->data) //greater than current
		{
			bool returnValue = erase(data, currentNode->rightChild, begin);
			if (decrease)
			{
				
				switch (currentNode->balance)
				{
				case BALANCED:
					currentNode->balance = LEFT_HEAVY;
					decrease = false; // overal hieght unchanged. the right still is holding it up
					break;
				case LEFT_HEAVY: // balance was at -1, now at -2
					rebalanceRight(currentNode, true);
					decrease = false;
					break;
				case RIGHT_HEAVY:
					currentNode->balance = BALANCED;
					break;
				}
			}
			return returnValue;
		}


		else // found item. NEED TO SET PARENT BALANCE, IT IS STAYING THE SAME HERE, NEEDS TO SHIFT ACCORDINGly
		{
			decrease = true;
			Node* old_root = currentNode;

			if (currentNode->leftChild == NULL) // no left child, replace w/ right
				currentNode = currentNode->rightChild;

			else if (currentNode->rightChild == NULL) // no right child, replace w/ left
				currentNode = currentNode->leftChild;

			else
				replaceParent(old_root, old_root->leftChild); // both kids, 
	

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			// LEFT OFF HERE. THE commented out thing below is the last thing you did. calling the root causes it to fail at zero. without we fail when try to remove root -50 cause balance is messed up
			delete old_root;
			/*if (root != NULL) 
				root->getHeight();*/
			return true;
		}
	}
}

//Used in erase for replacing nodes that have 2 children. From Texbook
void BST::replaceParent(Node* &old_root, Node* &local_root) 
{
	bool ignore = false;
	if (local_root->rightChild != NULL) // finds in order predeccessor. so while right child
	{
		root->getHeight(); // will help to update the height, and therefore the balance.


		if (local_root->rightChild->rightChild == NULL) // local root is now looking at the parent of the predessors
			local_root->balance -= 1; // its losing right child. need to update balance.
		

		if (local_root->balance == -2) // will be called on second to last iteration, however, it screws up where local_root is. 
		{
			local_root->balance = -1; // rebalance doesn't work with -2, so we need to move it back
			rebalanceRight(local_root, true);
			//moves where local root should be point, so we do a special call
			replaceParent(old_root, local_root->rightChild->rightChild);
			//root->getHeight(); // will help to update the height, and therefore the balance.
			ignore = true;
		}
		else
			replaceParent(old_root, local_root->rightChild);

		root->getHeight(); // will help to update the height, and therefore the balance.
		if (local_root->rightChild != NULL && local_root->rightChild->balance == -2  /*&& local_root->rightChild->leftChild != NULL */)
			rebalanceRight(local_root->rightChild, true);

		if (root->leftChild->balance == -2 && root->leftChild->leftChild != NULL)
			rebalanceRight(root->leftChild, true);


	}
	else
	{
		old_root->data = local_root->data;
		old_root = local_root;
		local_root = local_root->leftChild;
	}
}

//from textbook
Node * BST::rotateRight(Node* &currentNode)
{
	Node* temp = currentNode->leftChild;
	currentNode->leftChild = temp->rightChild;
	temp->rightChild = currentNode;
	currentNode = temp;
	return NULL;
}

//from textbook
Node * BST::rotateLeft(Node* &currentNode)
{
	Node* temp = currentNode->rightChild;
	currentNode->rightChild = temp->leftChild;
	temp->leftChild = currentNode;
	currentNode = temp;

	return NULL;
}

//from textbook, but with commanded w/ modified rebalance influence by bool removal
void BST::rebalanceLeft(Node* &current, bool removal)
{
	if (!removal) // rebalance for adding. balance -2
	{
		Node* BST_local_root = dynamic_cast<Node*>(current);
		Node* left_child = dynamic_cast<Node*>(current->leftChild);

		if (left_child->balance == RIGHT_HEAVY) //left right case
		{
			Node* left_right_child = dynamic_cast<Node*>(left_child->rightChild);
			if (left_right_child->balance == LEFT_HEAVY) 
			{
				left_child->balance = BALANCED;
				left_right_child->balance = BALANCED;
				BST_local_root->balance = RIGHT_HEAVY;
			}
			else if (left_right_child->balance == BALANCED)
			{
				left_child->balance = BALANCED;
				left_right_child->balance = BALANCED;
				BST_local_root->balance = BALANCED;
			}
			else
			{
				left_child->balance = LEFT_HEAVY;
				left_right_child->balance = BALANCED;
				BST_local_root->balance = BALANCED;
			}
			rotateLeft(current->leftChild);
		}
		else //left left case
		{
			left_child->balance = BALANCED;
			BST_local_root->balance = BALANCED;
		}
		rotateRight(current);
	}
	else // rebalnce for removing. called when balance is +2, so we'll need to rotate right
	{
		Node* BST_local_root = dynamic_cast<Node*>(current);
		Node* right_child = dynamic_cast<Node*>(current->rightChild);

		if (right_child->balance == LEFT_HEAVY)
		{
			Node* right_left_child = dynamic_cast<Node*>(right_child->rightChild);
			if (right_left_child->balance == RIGHT_HEAVY)
			{
				right_child->balance = BALANCED;
				right_left_child->balance = BALANCED;
				BST_local_root->balance = LEFT_HEAVY;
			}
			else if (right_left_child->balance == BALANCED) // is this where the change needs to happen?
			{
				right_child->balance = BALANCED;
				right_left_child->balance = BALANCED;
				BST_local_root->balance = BALANCED;
			}
			else
			{
				right_child->balance = RIGHT_HEAVY;
				right_left_child->balance = BALANCED;
				BST_local_root->balance = BALANCED;
			}
			rotateRight(current->rightChild);
		}
		else //right right case
		{
			/*right_child->balance = BALANCED;

			BST_local_root->balance = BALANCED;*/
			if (right_child->balance != BALANCED)
				right_child->balance = BALANCED; // this might not be what we want, sets 7 to 0, but it needs to be -1...
			else if (right_child != NULL)
				right_child->balance = LEFT_HEAVY;

		}
		rotateLeft(current);
	}
}

//from textbook, but with commanded w/ modified rebalance influence by bool removal
void BST::rebalanceRight(Node* &current, bool removal)
{
	if (!removal) // adding right child. will be called on when balance is +2 
	{
		Node* BST_local_root = dynamic_cast<Node*>(current);
		Node* right_child = dynamic_cast<Node*>(current->rightChild);

		if (right_child->balance == LEFT_HEAVY)
		{
			Node* right_left_child = dynamic_cast<Node*>(right_child->rightChild);
			if (right_left_child->balance == RIGHT_HEAVY)
			{
				right_child->balance = BALANCED;
				right_left_child->balance = BALANCED;
				BST_local_root->balance = LEFT_HEAVY;
			}
			else if (right_left_child->balance == BALANCED)
			{
				right_child->balance = BALANCED;
				right_left_child->balance = BALANCED;
				BST_local_root->balance = BALANCED;
			}
			else
			{
				right_child->balance = RIGHT_HEAVY;
				right_left_child->balance = BALANCED;
				BST_local_root->balance = BALANCED;
			}
			rotateRight(current->rightChild);
		}
		else //right right case
		{
			//!REMOVAL. DON"T ACCIDENTALLY EDIT SETH
			right_child->balance = BALANCED;

			BST_local_root->balance = BALANCED;
		}
		rotateLeft(current);
	}
	//assert: removal = true
    else if (current->leftChild != NULL)// rebalance for removal. called when balance is -2
	{
		Node* BST_local_root = dynamic_cast<Node*>(current);
		Node* left_child = dynamic_cast<Node*>(current->leftChild);

		if (left_child->balance == RIGHT_HEAVY) //left right case
		{
			Node* left_right_child = dynamic_cast<Node*>(left_child->rightChild);
			if (left_right_child->balance == LEFT_HEAVY)
			{
				left_child->balance = BALANCED;
				left_right_child->balance = BALANCED;
				BST_local_root->balance = RIGHT_HEAVY;
			}
			else if (left_right_child->balance == BALANCED)
			{
				left_child->balance = BALANCED;
				left_right_child->balance = BALANCED;
				BST_local_root->balance = BALANCED;
			}
			else
			{
				left_child->balance = LEFT_HEAVY;
				left_right_child->balance = BALANCED;
				BST_local_root->balance = BALANCED;
			}
			rotateLeft(current->leftChild);
		}
		else //left left case
		{
			if (left_child->balance != BALANCED)
				left_child->balance = BALANCED;
			else if (left_child != NULL)
				left_child->balance = RIGHT_HEAVY;
        }
		rotateRight(current);
	}

}

void BST::clear()
{
	while (root != NULL)
		erase(root->getData(), root, true);
}
