/**
Under extentuating circumstances Dr Burton allowed to turn in this lab, despite looking at code from 
a student who took the class in previous years. His code allowed me to better understand the process.

Despite this, I have recoded the lab entirely based upon functions in the book, and not his.

I certify that ALL follows is based upon the book, and is either directly from the text, modified from text
or my own creations. 



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
From Dr Burton:

"I recommend that you complete the lab, that you acknowledge (with comments) where your code uses or is 
based heavily on outside sources, and that you include a statement that you alerted me  to outside help in advance 
of your submission and that I encouraged you to submit your solution with attribution."



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



ALL FUNCTIONS ARE NOTED IN COMMENTS. THEY ARE ALL FROM BOOK OR MY OWN. IN THE END I MANAGED TO COMPLETE W/O OUTSIDE HELP.


*/


#pragma once
#include "AVLInterface.h"
#include "BST.h"
class AVL :
	public AVLInterface
{
public:
	AVL();
~AVL();

NodeInterface* getRootNode();
bool add(int data);
bool remove(int data);

private:
	BST groot;
};

